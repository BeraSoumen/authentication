from django.urls import path
from notepad import views

urlpatterns = [
    path('',views.home,name='home'),
    path('delete_note/<str:pk>',views.delete_note,name='delete'),
    path('update_note/<str:pk>',views.update_note,name='update'),
    path('logout',views.logout_user,name='logout'),
    path('login',views.login_user,name='login')
]
