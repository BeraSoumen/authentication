


from django.shortcuts import redirect, render
from django.http import HttpResponse
from .models import Note
from django.contrib.auth import logout,authenticate,login

# Create your views here.
def home(request):
               if request.method =='POST':
                              s1=request.POST['title']
                              s2=request.POST['Description']
                              Note.objects.create(title=s1,description=s2)
                              return redirect('home')
              
               obj=Note.objects.all()
               context={'notes':obj}


               
               return render(request,'home.html',context)

def delete_note(request,pk):
               obj=Note.objects.get(id=pk)
               obj.delete()
               return redirect('home')

def update_note(request,pk):
                obj=Note.objects.get(id=pk)
                privious_title=obj.title
                privious_description=obj.description
                print(privious_title,privious_description)
                if  request.method=="POST":
                               new_title=request.POST['title']
                               new_description=request.POST['Description']
                               obj.title=new_title
                               obj.description=new_description
                               obj.save()
                               return redirect('home')

                obj=Note.objects.all()
                context={'notes':obj,'title':privious_title,'description':privious_description}
                return render(request,'home.html',context)


def logout_user(request):
               logout(request)
               return redirect('home')

def login_user(request):
               if request.method =='POST':
                              Username=request.POST['username']
                              Password=request.POST['password']
                              user=authenticate(username=Username,password=Password)
                              if user is not None:
                                             login(request,user)
                                             return redirect('home')
                              

                              print(Username,Password)
               return render(request, 'login.html')